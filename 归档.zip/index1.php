<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>myself</title>
    <style type="text/css">
        .body {
            width: 80%;
            margin: auto;
        }
        .title {
            text-align:center;
            font-size: 25px;
        }
        .space {
            height: 30px;
        }

        img{
            display: block;
            margin:0 auto;
        }
    </style>
</head>
<body>
<div class="body">
    <p class="title"><?php echo $list->title; ?></p>
    <?php foreach($results as $result): ?>
        <div class="space"></div>
        <?php $result->urls = json_decode($result->urls); ?>
        <?php foreach ($result->urls as $url): ?>
            <div>
                <img src="<?php echo $url; ?>" />
            </div>
        <?php endforeach; ?>
        <p align="center">
            下载地址:<a href="<?php echo $result->down_urls;?>"><?php echo $result->title; ?></a>
        </p>
    <?php endforeach; ?>
</div>
</body>
</html>