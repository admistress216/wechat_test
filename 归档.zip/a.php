<?php
ini_set('display_errors', 'on');
error_reporting(E_ALL);

include './Mysql/database.php';
include 'Mysql/MysqlPDO.php';

$instance = MysqlPDO::getInstance($db['default']);
$list = $instance->query("select * from list where id=1")[0];

$results = $instance->query("select * from source where id in (".$list->child.")");
include 'index1.php';